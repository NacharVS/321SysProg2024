﻿namespace StrategyUnits
{
    public delegate void ChageHealth(int health, int maxhealth, string? name);

    internal class Unit : IHealthControl
    {
        private int _health;
        private string? _name;
        private int _maxhealth;


        public Unit(int health, string? name)
        {
            _health = health;
            _name = name;
            _maxhealth = health;
        }


        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public int MaxHealth
        {
            get => _maxhealth;
        }


        public virtual int Health 
        { 
            get => _health;
            set
            { if (_health < value)
                { ChageIncreaseHealth(value,_maxhealth,_name); }
                else
                { ChageDecreaseHealth(value,_maxhealth, _name); }

                if (value <= 0)
                {
                     _health = 0;
                    Console.WriteLine($"{_name} сдох");
                }
                else  if (value >= MaxHealth)
                {
                    _health = MaxHealth;
                }
                else
                {
                    _health = value;
                }
            }
        }

        public void Move()
        {
            Console.WriteLine("Is moving");
        }

        public virtual void ShowInfo()
        {
            Console.WriteLine($"Unit: {_name} Health: {_health}/{_maxhealth} ");
        }

        public void TakeDamage(int damage)
        {
            Health -= damage;
        }

        //public void TakeDamage(int Damage)
        //{
        //    //Damage = Damage <= 0? 0 : Damage - Armor;
        //    if(Armor > Damage)
        //    {
        //        Armor = Armor - Damage;
        //        Health = Health;
        //    }
        //    else if(Armor == Damage)
        //    {
        //        Health = Health;
        //    }
        //    else
        //    {
        //        Damage = Damage - Armor;
        //        Health = Health - Damage;
        //    }

        //}

        public event ChageHealth ChageIncreaseHealth;
        public event ChageHealth ChageDecreaseHealth;
    }
}
