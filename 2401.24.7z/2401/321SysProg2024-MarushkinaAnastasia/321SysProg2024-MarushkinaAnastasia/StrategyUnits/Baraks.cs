﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace StrategyUnits
{
    internal class Baraks
    {
        public Footman CreateRecruitFootman()
        {
            return new Footman("Recruit", 60, 3, 2, 5);
        }

        public Footman CreateAdvansedFootman()
        {
            return new Footman("Footman", 80, 4, 5, 8);
        }
        public Footman CreateVeteranFootman()
        {
            return new Footman("Veteran", 100, 5, 8, 11);
        }
        public Peasant CreateYoungPeasant()
        {
            return new Peasant("Молодой крестьянин", 20);
        }
        public Peasant CreatePeasant()
        {
            return new Peasant("Крестьянин", 30);
        }
        public Peasant CreateOldPeasant()
        {
            return new Peasant("Бывалый крестьянин", 35);
        }
        public Berserker CreateBerserker()
        {
            return new Berserker("Berserker", 60, 2, 10, 23);
        }

        public Knight CreateKnight()
        {
            return new Knight(120,"Knight", 10, 1,100, 5, 10);
        }

        public Knight CreatePalladin()
        {
            return new Paladin(150, "Paladin", 15, 1, 200, 7, 14);
        }


    }
}
