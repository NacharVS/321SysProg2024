﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyUnits
{
    internal class Berserker: MilitaryUnit
    {
        
        public Berserker(string? name, int health, int armor, int mindamage, int maxdamage) : base(health, name, armor, mindamage, maxdamage)
        {
            Rage = false;
        }

        public bool Rage { get; set; }

        public override int Health
        {
            get { return base.Health; }
            set
            {
                base.Health = value;
                if (value <= MaxHealth / 2 && !Rage)
                {
                    Rage = true;
                    MinDamage *= 2;
                    MaxDamage *= 2;
                    Console.WriteLine("Активировалась ярость");
                }
                else if (value > MaxHealth / 2 && Rage)
                {
                    MinDamage /= 2;
                    MaxDamage /= 2;
                    Rage = false;
                    Console.WriteLine("Ярость пропала");
                }

            }

        }

        public override void Attack(Unit unit)
        {
            int damage = new Random().Next(MinDamage, MaxDamage);
            Console.WriteLine($"Берсерк нанесн ударом топора {damage} урона Юниту: {unit.Name}");
            unit.TakeDamage(damage);
        }

    }
}
