﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyUnits
{
    internal class MilitaryUnit: IHealthControl, IArmorControll
    {
        public int _maxdamage;
        public int _mindamage;
        
        
        public MilitaryUnit(int health, string? name, int armor, int mindamage, int maxdamage) 
        {
            _mindamage =mindamage;
            _maxdamage =maxdamage;
        }

        public int MinDamage
        {
            get { return _mindamage; } 
            set { _mindamage = value; } 
        }

        public int MaxDamage
        {
            get { return _maxdamage; }
            set { _maxdamage = value; }
        }

        public int Defense { get; set; }
        public int Health { get ; set ; }
        public string Name { get; set; }

        public virtual void Attack(Unit unit)
        {
            Console.WriteLine("✦  Attack!  ✦");
        }

        public void Move()
        {
            Console.WriteLine("Is moving");
        }

        public override void ShowInfo()
        {
            Console.WriteLine($"Unit: {Name} Health: {_health}/{_maxhealth}");
        }

        public void TakeDamage(int damage)
        {
            throw new NotImplementedException();
        }
    }
}
