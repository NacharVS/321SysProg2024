﻿namespace StrategyUnits
{
    internal class Peasant : Unit
    {
        //public Peasant() : base(30, "Peasant", 0)
        //{
        //}
        public Peasant(string? name, int health) : base(health, name)
        {
            
        }
    }
}
