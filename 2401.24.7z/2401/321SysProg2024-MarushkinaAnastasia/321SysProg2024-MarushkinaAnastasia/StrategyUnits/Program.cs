﻿using StrategyUnits;
using System;
using System.Xml.Linq;

namespace StrategyUnits
{
    class Program
    {
        static void Main()
        {
            Baraks baraks = new Baraks();
            Footman footman = baraks.CreateAdvansedFootman();
            Footman footman2 = baraks.CreateRecruitFootman();
            Peasant ps1 = baraks.CreateYoungPeasant();
            Peasant ps2 = baraks.CreatePeasant();
            Peasant ps3 = baraks.CreateOldPeasant();
            Wizard wizard = new Wizard();
            Temple temple = new Temple();
            Berserker berserker = baraks.CreateBerserker();
            Knight knight = baraks.CreateKnight();
           
            
            ps1.ChageIncreaseHealth += IncreseHealth;
            ps1.ChageDecreaseHealth += DecreseHealth;
            ps2.ChageIncreaseHealth += IncreseHealth;
            ps2.ChageDecreaseHealth += DecreseHealth;
            footman2.ChageIncreaseHealth += IncreseHealth;
            footman2.ChageDecreaseHealth += DecreseHealth;
            berserker.ChageIncreaseHealth += IncreseHealth;
            berserker.ChageDecreaseHealth += DecreseHealth;
            knight.ChageIncreaseHealth += IncreseHealth;
            knight.ChageDecreaseHealth += DecreseHealth;
            footman.ChageIncreaseHealth += IncreseHealth;
            footman.ChageDecreaseHealth += DecreseHealth;
            
            knight.Attack(ps2);
            footman2.Attack(berserker);
            footman.Attack(berserker);
            footman2.Attack(berserker);
            footman.Attack(berserker);
            footman2.Attack(berserker);
            footman.Attack(berserker);
            footman2.Attack(berserker);
            footman2.Attack(berserker);
            footman2.Attack(berserker);
            footman2.Attack(berserker);
            footman2.Attack(berserker);
            footman2.Attack(berserker);
            footman2.Attack(berserker);
            footman2.Attack(berserker);
            footman2.Attack(berserker);
            footman2.Attack(berserker);
            footman2.Attack(berserker);
            footman2.Attack(berserker);
            footman2.Attack(berserker);
            footman2.Attack(berserker);
            footman2.Attack(berserker);
            footman2.Attack(berserker);
            berserker.Attack(footman);
            footman.Attack(knight);
            //footman2.Attack(knight);
            //knight.SelfHeal(knight);
            

            berserker.Attack(footman2);

            wizard.ShowInfo();
            wizard.InflictTreat(ps2);
            wizard.InflictTreat(ps2);
            berserker.Attack(knight);
            knight.ShowInfo();
            knight.SelfHeal();
            knight.ShowInfo();
            //temple.InflictMAna(wizard);
            //temple.ShowInfo();

        }
        static void IncreseHealth(int health, int maxhealth, string? name, int armor)
        {

            Console.WriteLine($"Юнит: {name} Текущее здоровье: {health}/{maxhealth} Armor:{armor} ");
        }
        static void DecreseHealth(int health, int maxhealth, string? name, int armor)
        {
            Console.WriteLine($"Юнит: {name} Текущее здоровье: {health}/{maxhealth} Armor:{armor}");
        }
    }

}


