﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyUnits
{
    internal class Knight : MagicUnit
    {
        public Knight(int health, string? name, int armor, int treat, int energy, int mindamage, int maxdamage) 
            : base(health, name, armor, treat, energy, mindamage, maxdamage)
        {
        }

        public override void Attack(Unit unit)
        {
            int damage = new Random().Next(MinDamage, MaxDamage);
            Console.WriteLine($"Рыцарь нанесн ударом меча {damage} урона Юниту: {unit.Name}");
            unit.TakeDamage(damage);
        }
        public void SelfHeal( )
        {
            while (Health < MaxHealth && (Energy / 2) > 0)
            {
                Health += Treat;
                Energy -= 2;
            }
        }
        public override void ShowInfo() => Console.WriteLine($"Unit: {this.Name} Health: {this.Health}/{this.MaxHealth} Energy: {Energy}");
    }
}
