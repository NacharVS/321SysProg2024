﻿using StrategyUnits;

Footman footman = new Footman();
Footman footman2 = new Footman();
Peasant ps1 = new Peasant();
Wizard wizard = new Wizard();
Temple temple = new Temple();

footman.Attack(ps1);
ps1.ShowInfo();
